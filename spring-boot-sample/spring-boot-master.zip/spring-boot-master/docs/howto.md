# How Do I Do That With Spring Boot?

**The How-to is now part of the reference documentation.**

The How-to guide has moved and is now published as part of the reference documentation.
You can find the latest browsable copy at
http://docs.spring.io/spring-boot/docs/current-SNAPSHOT/reference/htmlsingle/#howto

If you want to contribute to the How-to the source is available at
[`spring-boot-docs/src/main/asciidoc/howto.adoc`](../spring-boot-docs/src/main/asciidoc/howto.adoc).
